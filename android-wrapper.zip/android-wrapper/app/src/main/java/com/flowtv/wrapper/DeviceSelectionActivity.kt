package com.flowtv.wrapper

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView

class DeviceSelectionActivity : AppCompatActivity() {

    private lateinit var devicePreference: DevicePreference
    private lateinit var ivLogo: ImageView
    private lateinit var tvTitle: TextView
    private lateinit var tvSubtitle: TextView
    private lateinit var cardMobile: MaterialCardView
    private lateinit var cardTv: MaterialCardView
    private lateinit var btnContinue: MaterialButton
    private var selectedDeviceType: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_device_selection)

        initViews()
        devicePreference = DevicePreference(this)

        // Hide continue button - we navigate immediately on card click
        btnContinue.visibility = View.GONE

        setupListeners()
        startAnimations()
    }

    private fun initViews() {
        ivLogo = findViewById(R.id.ivLogo)
        tvTitle = findViewById(R.id.tvTitle)
        tvSubtitle = findViewById(R.id.tvSubtitle)
        cardMobile = findViewById(R.id.cardMobile)
        cardTv = findViewById(R.id.cardTv)
        btnContinue = findViewById(R.id.btnContinue)
    }

    private fun setupListeners() {
        cardMobile.setOnClickListener {
            saveAndNavigate(Constants.DEVICE_TYPE_MOBILE)
        }

        cardTv.setOnClickListener {
            saveAndNavigate(Constants.DEVICE_TYPE_TV)
        }

        cardMobile.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                ViewCompat.animate(cardMobile)
                    .scaleX(1.05f)
                    .scaleY(1.05f)
                    .setDuration(200)
                    .setInterpolator(AccelerateDecelerateInterpolator())
                    .start()
                cardMobile.cardElevation = 12f
            } else {
                ViewCompat.animate(cardMobile)
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(200)
                    .setInterpolator(AccelerateDecelerateInterpolator())
                    .start()
                cardMobile.cardElevation = 0f
            }
        }

        cardTv.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                ViewCompat.animate(cardTv)
                    .scaleX(1.05f)
                    .scaleY(1.05f)
                    .setDuration(200)
                    .setInterpolator(AccelerateDecelerateInterpolator())
                    .start()
                cardTv.cardElevation = 12f
            } else {
                ViewCompat.animate(cardTv)
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(200)
                    .setInterpolator(AccelerateDecelerateInterpolator())
                    .start()
                cardTv.cardElevation = 0f
            }
        }
    }

    private fun saveAndNavigate(type: String) {
        devicePreference.setDeviceType(type)
        if (type == Constants.DEVICE_TYPE_MOBILE) {
            NavigationManager.navigateToMainActivity(this)
        } else {
            NavigationManager.navigateToTvWebViewActivity(this)
        }
        finish()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    private fun startAnimations() {
        val handler = Handler(Looper.getMainLooper())
        
        handler.postDelayed({
            ViewCompat.animate(ivLogo)
                .alpha(1f)
                .translationY(0f)
                .setDuration(400)
                .setInterpolator(AccelerateDecelerateInterpolator())
                .start()
        }, 100)

        handler.postDelayed({
            ViewCompat.animate(tvTitle)
                .alpha(1f)
                .translationY(0f)
                .setDuration(400)
                .setInterpolator(AccelerateDecelerateInterpolator())
                .start()
        }, 200)

        handler.postDelayed({
            ViewCompat.animate(tvSubtitle)
                .alpha(1f)
                .translationY(0f)
                .setDuration(400)
                .setInterpolator(AccelerateDecelerateInterpolator())
                .start()
        }, 300)

        handler.postDelayed({
            ViewCompat.animate(cardMobile)
                .alpha(1f)
                .translationX(0f)
                .setDuration(500)
                .setInterpolator(AccelerateDecelerateInterpolator())
                .start()

            ViewCompat.animate(cardTv)
                .alpha(1f)
                .translationX(0f)
                .setDuration(500)
                .setInterpolator(AccelerateDecelerateInterpolator())
                .start()
        }, 400)
    }
}

